class Post < ApplicationRecord
	validates :title, presence:true,
						length:(min : 5)

end
